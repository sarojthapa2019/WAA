package edu.mum.cs.producttest.repositoryimpl;

import edu.mum.cs.producttest.domain.Category;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CategoryRepositoryH2 extends CrudRepository<Category, Integer> {

    Optional<Category> findByName(String name);

}
