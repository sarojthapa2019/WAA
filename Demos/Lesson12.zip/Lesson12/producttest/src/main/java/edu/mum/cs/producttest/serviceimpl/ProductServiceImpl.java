package edu.mum.cs.producttest.serviceimpl;

import java.util.List;

import edu.mum.cs.producttest.domain.Product;
import edu.mum.cs.producttest.repository.ProductRepository;
import edu.mum.cs.producttest.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepository productRepository;
	
  	public List<Product> getAll() {
		return productRepository.getAll();
	}
	
	public void save(Product product) {
		productRepository.save(product);
		return ;
	}
	
  	public Product findOne(Long id) {
		return productRepository.findOne( id);
	}
	

		   
}
 
