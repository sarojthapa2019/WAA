package edu.mum.cs.producttest.serviceimpl;

import java.util.List;

import edu.mum.cs.producttest.domain.Category;
import edu.mum.cs.producttest.repository.CategoryRepository;
import edu.mum.cs.producttest.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CategoryServiceImpl implements CategoryService {

    CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public List<Category> getAll() {
        return categoryRepository.getAll();
    }

    public Category getCategory(int id) {
        return categoryRepository.getCategory(id);
    }


}
 
