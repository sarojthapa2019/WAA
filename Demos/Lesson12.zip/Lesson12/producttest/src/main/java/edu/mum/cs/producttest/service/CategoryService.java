package edu.mum.cs.producttest.service;

import edu.mum.cs.producttest.domain.Category;

import java.util.List;


public interface CategoryService {

    public Category getCategory(int id);

    public List<Category> getAll();


}
 
