package edu.mum.cs.producttest.service;

import edu.mum.cs.producttest.domain.Product;

import java.util.List;


public interface ProductService {

    // Returns a List of all Products
    public List<Product> getAll();

    // Save a Product
    public void save(Product product);

    // Find a Product by id
    public Product findOne(Long id);


}
 
