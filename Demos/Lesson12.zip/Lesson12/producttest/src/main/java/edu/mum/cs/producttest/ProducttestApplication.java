package edu.mum.cs.producttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducttestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProducttestApplication.class, args);
    }

}
