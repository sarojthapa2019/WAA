package edu.mum.cs.producttest.repository;

import edu.mum.cs.producttest.domain.Category;

import java.util.List;


public interface CategoryRepository {

    public Category getCategory(int id);

    public List<Category> getAll();


}
 
