package edu.mum.cs.producttest.controller;

import java.util.List;


import edu.mum.cs.producttest.domain.Category;
import edu.mum.cs.producttest.domain.Product;
import edu.mum.cs.producttest.service.CategoryService;
import edu.mum.cs.producttest.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;

    @RequestMapping(value = {"/", "/product"}, method = RequestMethod.GET)
    public String inputProduct(@ModelAttribute("product") Product newProduct, Model model) {
        List<Category> categories = categoryService.getAll();
        model.addAttribute("categories", categories);
        return "ProductForm";
    }

    @RequestMapping(value = {"/", "/product"}, method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("product") Product product) {
        Category category = categoryService.getCategory(product.getCategory().getId());
        product.setCategory(category);

        productService.save(product);

        return "ProductDetails";
    }


    @RequestMapping(value = "/listproducts", method = RequestMethod.GET)
    public String listProducts(Model model) {
        List<Product> list = productService.getAll();
        model.addAttribute("products", list);

        return "ListProducts";
    }

}
