package edu.mum.cs.producttest.repository;

import edu.mum.cs.producttest.domain.Product;

import java.util.List;


public interface ProductRepository {

    public List<Product> getAll();

    public void save(Product product);

    public Product findOne(Long id);

}
 
