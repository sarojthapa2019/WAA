INSERT INTO Category VALUES (1, 'Travel');
INSERT INTO Category VALUES (2, 'Computer');
INSERT INTO Category VALUES (3, 'HomeGoods');