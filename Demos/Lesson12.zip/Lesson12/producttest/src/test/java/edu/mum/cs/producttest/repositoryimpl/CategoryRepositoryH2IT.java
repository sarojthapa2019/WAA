package edu.mum.cs.producttest.repositoryimpl;

import edu.mum.cs.producttest.domain.Category;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@DataJpaTest
public class CategoryRepositoryH2IT {

    @Autowired
    CategoryRepositoryH2 categoryRepositoryH2;

    @Before
    public void setUp() throws Exception {
    }

    @Test
//    @DirtiesContext
    public void findByName() throws Exception{
        Optional<Category> categoryOptional = categoryRepositoryH2.findByName("Computer");
        assertEquals("Computer", categoryOptional.get().getName());
    }

    @Test
    public void findByName2() throws Exception{
        Optional<Category> categoryOptional = categoryRepositoryH2.findByName("Travel");
        assertEquals("Travel", categoryOptional.get().getName());

    }
}