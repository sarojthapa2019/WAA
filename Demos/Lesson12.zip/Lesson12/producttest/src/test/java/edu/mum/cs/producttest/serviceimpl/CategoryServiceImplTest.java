package edu.mum.cs.producttest.serviceimpl;

import edu.mum.cs.producttest.builder.CategoryBuilder;
import edu.mum.cs.producttest.builder.CategoryListBuilder;
import edu.mum.cs.producttest.domain.Category;
import edu.mum.cs.producttest.repositoryimpl.CategoryRepositoryImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.Assert.*;

public class CategoryServiceImplTest {

    CategoryServiceImpl categoryService;

    @Mock
    CategoryRepositoryImpl categoryRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        categoryService = new CategoryServiceImpl(categoryRepository);
    }

    @Test
    public void getAll() {
        List<Category> categoryList = new CategoryListBuilder().build();

        Mockito.when(categoryRepository.getAll()).thenReturn(categoryList);

        List<Category> result = categoryService.getAll();
        assertEquals(categoryList.size(), categoryList.size());

        //verify getAll() is called only once
        Mockito.verify(categoryRepository, Mockito.times(1)).getAll();

    }
}