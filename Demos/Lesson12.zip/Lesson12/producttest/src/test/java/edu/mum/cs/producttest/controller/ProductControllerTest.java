package edu.mum.cs.producttest.controller;

import edu.mum.cs.producttest.builder.ProductListBuilder;
import edu.mum.cs.producttest.domain.Product;
import edu.mum.cs.producttest.service.CategoryService;
import edu.mum.cs.producttest.service.ProductService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;

import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class ProductControllerTest {

    @Mock
    private ProductService productServiceMock;

    @Mock
    private CategoryService categoryServiceMock;

    @Mock
    private Model model;

    @InjectMocks
    private ProductController productController;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void inputProduct() {
        String viewName = productController.inputProduct(new Product(), model);
        assertEquals("ProductForm", viewName);
        verify(categoryServiceMock, times(1)).getAll();
        verify(model, times(1)).addAttribute(eq("categories"), anyList());
    }

    @Test
    public void listProducts() {
        List<Product> productList = new ProductListBuilder().build();
        when(productServiceMock.getAll()).thenReturn(productList);

        ArgumentCaptor<List<Product>> argumentCaptor = ArgumentCaptor.forClass(List.class);

        String viewName = productController.listProducts(model);
        assertEquals("ListProducts", viewName);
        verify(productServiceMock, times(1)).getAll();
        verify(model, times(1)).addAttribute(eq("products"), argumentCaptor.capture());
        List<Product> setInController = argumentCaptor.getValue();
        assertEquals(productList.size(), setInController.size());
    }
}