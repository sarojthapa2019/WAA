package edu.mum.cs.producttest.builder;

import edu.mum.cs.producttest.domain.Category;
import edu.mum.cs.producttest.domain.Product;

import java.util.Arrays;
import java.util.List;


public class CategoryListBuilder {

    public CategoryBuilder categoryBuilderOne = new CategoryBuilder().withId(1).withName("Computer");

    public CategoryBuilder categoryBuilderTwo = new CategoryBuilder()
            .withId(2)
            .withName("Solids");

    public List<Category> build() {
        return Arrays.asList(categoryBuilderOne.build(), categoryBuilderTwo.build());
    }

    public CategoryBuilder getCategoryBuilderOne() {
        return categoryBuilderOne;
    }

}
