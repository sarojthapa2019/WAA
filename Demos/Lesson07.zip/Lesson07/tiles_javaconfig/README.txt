<dependency>
			<groupId>org.apache.tiles</groupId>
			<artifactId>tiles-jsp</artifactId>
			<version>3.0.8</version>
		</dependency>
		
This dependency only supports for default configuration which means no wildcard, no prefix in the tile-definition.

See tilewildcard_xml for advanced usage.