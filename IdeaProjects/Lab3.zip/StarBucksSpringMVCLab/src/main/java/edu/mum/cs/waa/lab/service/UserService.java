package edu.mum.cs.waa.lab.service;

public interface UserService {
    String findPassword(String name);
}
