package edu.mum.cs.waa.lab.domain;

public class Advice {
    private String type;


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
